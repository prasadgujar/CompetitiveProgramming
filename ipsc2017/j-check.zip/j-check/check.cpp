#include "testlib.h"
#include <cmath>
#include <iostream>
using namespace std;

#define x first
#define y second
typedef pair<int,int> pii;
constexpr int maxLines = 1000;
constexpr int maxCoord = 10000;
int main(int argc, char * argv[])
{
    setName("calculates the number of regions to which plane is split using given lines");
    registerTestlibCmd(argc, argv);

    bool hard = string(argv[1]) == "hard.in";

    int T = inf.readInt();
    for (int t = 1; t <= T; ++t) {
        int N = inf.readInt();
        int K = ans.readInt();
        for (int i = 0; i < K; i++) {
            ans.readInt(); ans.readInt();
        }

        int AnsK = ouf.readInt(0, maxLines);
        if (hard && K != AnsK) {
            quitf(_wa, "test %d: got %d instead of %d", t, AnsK, K);
        }

        // remember all (a,b) tuples for lines ax+b to prevent one line from appearing multiple times
        set<pii> Lines;
        // remember all intersection points along with the number of pairs, where point is fractional tuple (x/d, y/d) and x/d is irreducible
        map<pair<pii, int>, int> IntersectionPoints;
        // remember count of parallel lines by slope
        map<int, int> ParallelLines;
        for (int i = 0; i < AnsK; i++) {
            int a = ouf.readInt(-maxCoord, maxCoord);
            int b = ouf.readInt(-maxCoord, maxCoord);

            if (Lines.find({a,b}) != Lines.end()) {
                continue;
            }

            for (pii l: Lines) {
                if (l.x == a) continue; // parallel lines don't have any intersection
                int xNumerator = l.y - b;
                int xDenominator = a - l.x;
                int g = __gcd(abs(xNumerator), abs(xDenominator));
                xNumerator /= g;
                xDenominator /= g;
                if(xDenominator < 0) {
                  xDenominator *= -1;
                  xNumerator *= -1;
                }
                int yNumerator = a * xNumerator + b * xDenominator;
                IntersectionPoints[{{xNumerator, yNumerator}, xDenominator}] += 1;
            }

            ParallelLines[a] += 1;
            Lines.insert({a,b});
        }

        int Regions = (Lines.size() * Lines.size() + Lines.size() + 2) / 2;
        for (auto Parallel: ParallelLines) {
            Regions -= Parallel.y * (Parallel.y-1) / 2;
        }

        for (auto IntersectionPoint : IntersectionPoints) {
            int pairs = IntersectionPoint.y;
            int lines = 1;
            while (lines * (lines - 1) / 2 < pairs) ++lines;
            Regions -= (lines - 1) * (lines - 2) / 2;
        }
        if (Regions != N) {
            quitf(_wa, "test %d: incorrect number of regions: %d instead of %d", t, Regions, N);
        }

    }

    quitf(_ok, "ok");
    // if (hard) {
    //     quitf(_ok, "%d cases - optimal", T);
    // } else {
    //     quitf(_ok, "%d cases", T);
    // }
}
